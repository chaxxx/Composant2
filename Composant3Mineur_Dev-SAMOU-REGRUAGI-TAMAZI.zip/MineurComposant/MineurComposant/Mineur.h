#pragma once

#include "Wallet.h"
#include "Block.h"
#include "Hacheur.h"


class Mineur sealed
{
public:
	int difficulte;
	Mineur();
	string SHA(Block,Hacheur);
	Block getBlock(Wallet, int);
	bool check_diff(string, int);
};

