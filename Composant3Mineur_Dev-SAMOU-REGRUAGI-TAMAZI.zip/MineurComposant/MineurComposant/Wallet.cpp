#include "pch.h"
#include "Wallet.h"


Wallet::Wallet()
{
}
