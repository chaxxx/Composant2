#include "Block.h"
#include <vector>

using namespace std;

#pragma once
class Wallet sealed
{
	

public:
	vector<Block> Blocks;
	Wallet();
};

