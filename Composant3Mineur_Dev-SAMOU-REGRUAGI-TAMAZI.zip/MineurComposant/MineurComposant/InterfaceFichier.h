#pragma once

#include "Block.h"

class InterfaceFichier sealed
{
public:
	bool addBlock(Block);
	InterfaceFichier();
};

