#include "pch.h"
#include "Hacheur.h"
#include <string>


// Applique le Hash sur le bloc et retourne un String
string Hacheur::Hash(Block)
{

	return string("X000");
}

Hacheur::Hacheur()
{
}


Hacheur::~Hacheur()
{
}
