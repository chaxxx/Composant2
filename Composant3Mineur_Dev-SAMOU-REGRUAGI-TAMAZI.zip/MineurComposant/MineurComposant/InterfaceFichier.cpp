#include "pch.h"
#include "InterfaceFichier.h"


bool InterfaceFichier::addBlock(Block)
{
	return false;
}

InterfaceFichier::InterfaceFichier()
{
}
